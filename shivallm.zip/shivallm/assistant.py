import tkinter as tk
from tkinter import messagebox
from story_generator import generate_article  # Import the generate_article function from story_generator.py

class StoryGeneratorUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Story Generator")

        # Configure top frame with subtle green color
        self.top_frame = tk.Frame(self.root, bg="#f0f7f4", pady=10)
        self.top_frame.pack(fill="x")

        # Add logo or symbol beside the prompt entry
        self.icon_label = tk.Label(self.top_frame, text="📝", font=("Arial", 20), bg="#f0f7f4", fg="#60A561")
        self.icon_label.grid(row=0, column=0, padx=(10, 5))

        # Prompt label and entry with subtle interface color
        self.prompt_label = tk.Label(self.top_frame, text="Enter a story prompt:", fg="#333333", bg="#f0f7f4")
        self.prompt_label.grid(row=0, column=1)

        self.prompt_entry = tk.Entry(self.top_frame, width=50, fg="#333333", bg="#FFFFFF", relief="flat")
        self.prompt_entry.grid(row=0, column=2, padx=5)

        # Generate button with subtle green color
        self.generate_button = tk.Button(self.top_frame, text="Generate Story", command=self.generate_story, fg="#FFFFFF", bg="#60A561", relief="flat")
        self.generate_button.grid(row=0, column=3, padx=(5, 10))

        # Story text area with white background
        self.story_text = tk.Text(self.root, height=20, width=80, fg="#333333", bg="#FFFFFF")
        self.story_text.pack()

    def generate_story(self):
        prompt = self.prompt_entry.get()
        if not prompt:
            messagebox.showerror("Error", "Please enter a prompt.")
            return

        self.story_text.delete(1.0, tk.END)
        generated_story = generate_article(prompt)
        self.story_text.insert(tk.END, generated_story)

    def start(self):
        self.root.mainloop()

# Create and start the UI
if __name__ == "__main__":
    app = StoryGeneratorUI()
    app.start()


import openai
import time
from colorama import Fore, Style

# Set your OpenAI API key here
api_key = "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"

# Set your preferred model and parameters
model_name = "gpt-3.5-turbo-16k"
temperature = 0.6
default_max_tokens = 15000

# Initialize the OpenAI API client with your API key
openai.api_key = api_key

def generate_article(prompt, min_tokens=None, max_tokens=None):
    sections = []
    response = None
    total_tokens = 0

    while not response or (min_tokens and total_tokens < min_tokens):
        messages = [{"role": "user", "content": prompt}]

        start_time = time.time()

        response = openai.ChatCompletion.create(
            model=model_name,
            messages=messages,
            max_tokens=max_tokens - total_tokens if max_tokens else None,
            temperature=temperature,
            api_key=api_key
        )

        end_time = time.time()
        duration = end_time - start_time

        message = response["choices"][0]["message"]
        generated_text = message["content"].strip()
        finish_reason = message["role"]

        sections.append(generated_text)
        prompt = generated_text

        total_tokens += len(generated_text)

        # Check if the response is completed
        if finish_reason == "assistant":
            break

    # Print details for each section
    print(Fore.GREEN + f"Total characters generated: {len(generated_text)}" + Style.RESET_ALL)
    print(Fore.GREEN + f"Total words generated: {len(generated_text.split())}" + Style.RESET_ALL)
    print(Fore.GREEN + f"Section Generation Time: {duration:.2f} seconds" + Style.RESET_ALL + "\n")

    return "".join(sections)
